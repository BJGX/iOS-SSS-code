//
//  VFHomeModel.m
//  VFProject
//


//

#import "VFHomeModel.h"

@implementation VFHomeModel

+ (NSDictionary *)mj_replacedKeyFromPropertyName{
    return @{@"ID" : @"id"};
}


+ (NSDictionary *)mj_objectClassInArray {
    return @{
            @"banner": [self class],
            @"start": [self class]
            };
}


+ (UIImage *)getFlagImage:(NSString *)name
{
    NSString *imageName = @"";
    NSString *flagName = [self returnImageName:name];
    if ([name containsString:@"马来"]) {
        imageName = @"马来西亚";
    }
    
    else if ([name containsString:@"英国"] || [name containsString:@"英服"]) {
        imageName = @"英国";
    }
    else if ([name containsString:@"香港"] || [name containsString:@"Hong Kong"] || [name containsString:@"港服"]) {
        imageName = @"香港";
    }
    else if ([name containsString:@"日本"] || [name containsString:@"日服"]) {
        imageName = @"日本";
    }
    
    else if ([name containsString:@"Taiwan"] ) {
        imageName = @"台湾";
    }
    else if ([name containsString:@"韩服"]|| [name containsString:@"Korean"]|| [name containsString:@"韩国服"]) {
        imageName = @"韩国";
    }
    else if ([name containsString:@"新加坡"] || [name containsString:@"新服"]) {
        imageName = @"新加坡";
    }
    else if ([name containsString:@"美国"]|| [name containsString:@"美服"]) {
        imageName = @"美国";
    }
    
    else if ([name containsString:@"俄罗斯"]|| [name containsString:@"俄服"]) {
        imageName = @"俄罗斯";
    }
    
    else if ([name containsString:@"越南"]|| [name containsString:@"越服"]) {
        imageName = @"越南";
    }
    else if ([name containsString:@"非洲"]) {
        imageName = @"icon_asia_pacific";
    }
    
    else if (flagName != nil) {
        imageName = flagName;
    }
    
    
    return [UIImage imageNamed:imageName];
}

+ (NSString *)returnImageName:(NSString *)name
{
    NSArray *countries = @[
        @"Hong Kong",
        @"Taiwan",
        @"Korean",
        @"欧洲",
        @"台湾",
        @"加拿大",
        @"美国",
        @"墨西哥",
        @"澳大利亚",
        @"南非",
        @"阿根廷",
        @"巴西",
        @"哥伦比亚",
        @"智利",
        @"爱尔兰",
        @"爱沙尼亚",
        @"奥地利",
        @"保加利亚",
        @"比利时",
        @"冰岛",
        @"波兰",
        @"德国",
        @"俄罗斯",
        @"法国",
        @"荷兰",
        @"捷克",
        @"立陶宛",
        @"罗马尼亚",
        @"挪威",
        @"瑞典",
        @"瑞士",
        @"塞尔维亚",
        @"土耳其",
        @"乌克兰",
        @"西班牙",
        @"希腊",
        @"意大利",
        @"英国",
        @"阿塞拜疆",
        @"巴基斯坦",
        @"菲律宾",
        @"哈萨克斯坦",
        @"韩国",
        @"柬埔寨",
        @"马来西亚",
        @"孟加拉国",
        @"缅甸",
        @"尼泊尔",
        @"日本",
        @"泰国",
        @"香港",
        @"新加坡",
        @"印度",
        @"印度尼西亚",
        @"越南",
        @"阿联酋",
        @"阿曼",
        @"巴林",
        @"卡塔尔",
        @"沙特阿拉伯",
        @"伊拉克",
        @"以色列",
        @"免费",
        @"收藏"
    ];
    NSString *flag;
    for (NSString *obj in countries) {
        
        NSString *c1 = [obj substringToIndex:1];
        c1 = [NSString stringWithFormat:@"%@服",c1];
        NSString *en = obj.localized;
        if ([name containsString:obj] || [name containsString:c1] || [name containsString:en]) {
            flag = obj;
            break;
//            return obj;
        }
    }

    return flag;
}






@end
